-- MySQLShell dump 2.0.1  Distrib Ver 8.2.1 for macos13 on x86_64 - for MySQL 8.2.0 (MySQL Community Server (GPL)), for macos13 (x86_64)
--
-- Host: 34.75.9.212    Database: final-aung    Table: NYDataStructureView
-- ------------------------------------------------------
-- Server version	8.0.31

--
-- Temporary view structure for view `NYDataStructureView`
--

DROP TABLE IF EXISTS `NYDataStructureView`;
/*!50001 DROP VIEW IF EXISTS `NYDataStructureView`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `NYDataStructureView` AS SELECT
 1 AS `column_name`,
 1 AS `data_type`,
 1 AS `character_maximum_length` */;
SET character_set_client = @saved_cs_client;
